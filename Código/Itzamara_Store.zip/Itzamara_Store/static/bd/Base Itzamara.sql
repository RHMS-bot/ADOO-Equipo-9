-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Schema Itzamara1
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema Itzamara1
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `Itzamara1` DEFAULT CHARACTER SET utf8 ;
USE `Itzamara1` ;

-- -----------------------------------------------------
-- Table `Itzamara1`.`Cliente`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Itzamara1`.`Cliente` (
  `nombre` VARCHAR(50) NOT NULL,
  `contrasenia` VARCHAR(45) NOT NULL,
  `tel` VARCHAR(10) NOT NULL,
  PRIMARY KEY (`tel`))
ENGINE = InnoDB;

-- -----------------------------------------------------
-- Table `Itzamara`.`Cuquita`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Itzamara`.`Cuquita` (
  `nombre` VARCHAR(45) NOT NULL,
  `contrasenia` VARCHAR(45) NOT NULL,
  `tel` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`nombre`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `Itzamara1`.`Proveedor`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Itzamara1`.`Proveedor` (
  `nombre` VARCHAR(45) NOT NULL,
  `contacto` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`nombre`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `Itzamara1`.`Producto`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Itzamara1`.`Producto` (
  `codigo` INT NOT NULL AUTO_INCREMENT,
  `nombre` VARCHAR(45) NOT NULL,
  `precio` FLOAT NOT NULL,
  `cantidad` INT NOT NULL,
  `tipo` VARCHAR(45) NOT NULL,
  `imagen` VARCHAR(60) NOT NULL,
  `Proveedor_nombre` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`codigo`, `Proveedor_nombre`),
  INDEX `fk_Producto_Proveedor1_idx` (`Proveedor_nombre` ASC),
  CONSTRAINT `fk_Producto_Proveedor1`
    FOREIGN KEY (`Proveedor_nombre`)
    REFERENCES `Itzamara1`.`Proveedor` (`nombre`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `Itzamara1`.`Venta`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Itzamara1`.`Venta` (
  `idVenta` INT NOT NULL AUTO_INCREMENT,
  `tipopago` VARCHAR(45) NOT NULL,
  `total` INT NOT NULL,
  `fecha` DATE NOT NULL,
  `restante` FLOAT NOT NULL,
  `Producto_codigo` INT NOT NULL,
  `Cliente_tel` VARCHAR(10) NOT NULL,
  PRIMARY KEY (`idVenta`, `Producto_codigo`, `Cliente_tel`),
  INDEX `fk_Venta_Producto_idx` (`Producto_codigo` ASC),
  INDEX `fk_Venta_Cliente1_idx` (`Cliente_tel` ASC),
  CONSTRAINT `fk_Venta_Producto`
    FOREIGN KEY (`Producto_codigo`)
    REFERENCES `Itzamara1`.`Producto` (`codigo`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Venta_Cliente1`
    FOREIGN KEY (`Cliente_tel`)
    REFERENCES `Itzamara1`.`Cliente` (`tel`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `Itzamara1`.`Pago`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Itzamara1`.`Pago` (
  `idPago` INT NOT NULL AUTO_INCREMENT,
  `monto` FLOAT NOT NULL,
  `Venta_idVenta` INT NOT NULL,
  `Venta_Producto_codigo` INT NOT NULL,
  `Venta_Cliente_tel`  VARCHAR(10) NOT NULL,
  PRIMARY KEY (`idPago`, `Venta_idVenta`, `Venta_Producto_codigo`, `Venta_Cliente_tel`),
  INDEX `fk_Pago_Venta1_idx` (`Venta_idVenta` ASC, `Venta_Producto_codigo` ASC, `Venta_Cliente_tel` ASC),
  CONSTRAINT `fk_Pago_Venta1`
    FOREIGN KEY (`Venta_idVenta` , `Venta_Producto_codigo` , `Venta_Cliente_tel`)
    REFERENCES `Itzamara1`.`Venta` (`idVenta` , `Producto_codigo` , `Cliente_tel`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `Itzamara1`.`Compra`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Itzamara1`.`Compra` (
  `idCompra` INT NOT NULL AUTO_INCREMENT,
  `total` FLOAT NOT NULL,
  `fecha` DATE NOT NULL,
  `cantidad` INT NOT NULL,
  `Producto_codigo` INT NOT NULL,
  `Producto_Proveedor_idProveedor` INT NOT NULL,
  `Cuquita_idCuquita` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`idCompra`, `Producto_codigo`, `Producto_Proveedor_idProveedor`, `Cuquita_idCuquita`),
  INDEX `fk_Compra_Producto1_idx` (`Producto_codigo` ASC, `Producto_Proveedor_idProveedor` ASC),
  INDEX `fk_Compra_Cuquita1_idx` (`Cuquita_idCuquita` ASC),
  CONSTRAINT `fk_Compra_Producto1`
    FOREIGN KEY (`Producto_codigo` , `Producto_Proveedor_idProveedor`)
    REFERENCES `Itzamara`.`Producto` (`codigo` , `Proveedor_idProveedor`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Compra_Cuquita1`
    FOREIGN KEY (`Cuquita_idCuquita`)
    REFERENCES `Itzamara`.`Cuquita` (`idCuquita`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
